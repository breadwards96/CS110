CSQuiz.java

A ten question quiz. Results will be saved in a unique .txt file. The questions are randomly selected from a bank of 40 from the Java Fundamentals textbook, 5th ed. The distribution of questions by chapter is listed below; note that the selection is completely random, and you may receive every question from one chapter in your quiz:

1. Intro to Java	 3 questions
2. Java Fundamentals	10 questions
3. Decision Structures	 6 questions
4. Loops, File IO	 8 questions
5. Methods		 5 questions
6. Class basics		 4 questions
7. Arrays		 4 questions

A running total is kept of the score. At the end, the final score is displayed, as well as a grade, and a 'special' message for a perfect score. 

HOW TO USE

 - You will first be prompted to create the file your results will be saved in. THE FILE MUST CONTAIN THE .txt SUFFIX, OTHERWISE IT WILL CLOSE PREMATURELY! It will also close prematurely if the file name is already in the directory, so as not to overwrite another's work.

 - You will then be presented with each question in order. Make sure you answer A, B, C, or D. THE PROGRAM IS CASE SENSITIVE. ENTERING IN LOWERCASE VALUES WILL RESULT IN AN AUTOMATIC INCORRECT. 

 - The Java program will do everything else for you. If you want to see your results, look in the application's folder.

DISCLAIMER: I have changed some of the problems from the book around for convenience, for function, or otherwise. The Java book is a good study tool for the quiz, but none of the questions in the book should be expected to be seen here verbatim. Not responsible for loss of confidence due to low quiz score.

CITATION:

Gaddis, Tony. STARTING OUT WITH JAVA, FROM CONTROL STRUCTURES THROUGH OBJECTS, 5th ed. Haywood Community College: PEARSON EDUCATION, 2013. Print.