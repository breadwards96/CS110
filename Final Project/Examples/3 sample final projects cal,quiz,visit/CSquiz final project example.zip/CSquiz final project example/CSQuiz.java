// Author: Wiley Coyote
// Date 
// File: CS Quiz

/*    My final project for CS110 is this ten-question quiz. The program |
|  chooses ten questions out a much larger pool, asks each question,    |
|  receives input, and checks for correctness. Each question is worth   |
|  one point. The answers, and correctness are recorded on a .txt file, |
|  as well as the total score.                                         */

// import statements
import java.util.Scanner;
import java.io.*;
import java.util.Random;
import java.util.Collections;
import java.util.Arrays;

public class CSQuiz {
   // the main method
   public static void main(String[] args) throws IOException
   {
      // print the introductory statements about the quiz
      displayInstructions();
      
      // Declare a String to receive the name of the file
      String resultsName = null;
      
      // Creating a file to receive the results of the quiz
      Scanner keyboard = new Scanner(System.in);
      System.out.println("Your results will be saved in a .txt file.");
      System.out.print("Give the file a name (make sure it has .txt at"
                     + " the end), or type q to quit. ");
      resultsName = keyboard.nextLine();
      
      // Check name to see if it equals q
      int length = resultsName.length();
      if (resultsName.equals("q"))
      {
         System.out.println ("See you next time...");
         System.exit(0);
      }
      // Check to see if the name is long enough to contain the .txt suffix
      else if (length <= 5)
      {
         System.out.println ("Invalid file name. Restart the program, and try again");
         System.exit(0);
      }
      // Check to see if the name actually contains the .txt suffix
      String suffix = resultsName.substring((length - 4),length);
      
      if (!suffix.equals(".txt"))
      {
         System.out.println("File needs to have the suffix .txt. Restart  ");
         System.out.println("the program, and try again.                  ");
         System.exit(0);
      }
      
      // Check to see if the file already exists
      File file = new File(resultsName);
      if (file.exists())
      {
         System.out.println("This file already exists! We don't want       ");
         System.out.println("anybody to get mad, so we are closing the     ");
         System.out.println("program. Check the folder to see what names   ");
         System.out.println("are in use, and try again.                    ");
         System.exit(0);
      }
      
      // Open the file for printing
      PrintWriter results = new PrintWriter(file);
      
      // Begin writing to the file: Set up the table that will be used
      results.println(" Question Answer Correct ");
      results.println("-------------------------");
      
      // Create the array that will hold the question numbers
      final int QUESTIONS = 10;
      int[] q = new int[QUESTIONS];
      
      // Set each integer to 0.
      for (int p = 0; p < QUESTIONS; p++)
      {
         q[p] = 0;
      }
      
      // Create an integer, points, that will hold the total score
      int points = 0;
      
      // Invoke the getQuestionNums method to randomize the quiz
      getQuestionNums(q);
      
      /*// Check to see if the array is the same (checkpoint)
      for (int sent = 0; sent < QUESTIONS; sent++)
      {
         System.out.println(q[sent]);
      }*/
      
      // Ask the questions
      int t = 0;
      for (int x = 0; x < QUESTIONS; x++)
      {
         t = x + 1;
         points = ask(t, q[x], points, results);
         //System.out.println(points);//checkpoint
      }
      // Display the results
      displayResults(points);
      // Close the file
      results.close();
   }
   
   // A method that prints initial instructions
   public static void displayInstructions()
   {
      System.out.println("   Hello. You are about to take a ten-question,  ");
      System.out.println("multiple-choice quiz. The problems will be chosen");
      System.out.println("at random, and are based off of what was learned ");
      System.out.println("in your CS110 class.                             ");
      System.out.println("   For each question, answer A, B, C, or D.      ");
      System.out.println("Answering anything else will automatically result");
      System.out.println("in your answer being incorrect. Answering with a ");
      System.out.println("lowercase letter will also result in your answer ");
      System.out.println("being incorrect.                                 ");
      System.out.println("   Correct answers are worth one point. Incorrect");
      System.out.println("answers result in no points.                     ");
      System.out.println("   At the end of the quiz, your total score will ");
      System.out.println("be displayed. You can review your results later. ");
      System.out.println("                                                 ");
   }
   
   // A method that chooses values for the question numbers out of the total
   // number of questions.
   public static void getQuestionNums(int[] q)
   {
      // Choosing CHOOSE number of questions from pool of TOTAL
      final int TOTAL = 40; //Change if this number is different later!!
      final int CHOOSE = 10;
      
      // Create an array to hold the numbers 1 through TOTAL
      Integer[] pool = new Integer[TOTAL];
      
      // Make each int has a sequential number, from one to TOTAL
      for (int z = 0; z < TOTAL; z++)
      {
         int y = (z + 1);
         pool[z] = y;
      }
      
      /*// print out the ordered list (checkpoint)
      for (int order = 0; order < TOTAL; order++)
      {
         System.out.println(pool[order]);
      }*/
      
      // Sort the array
      Collections.shuffle(Arrays.asList(pool));
      
      /*// print out the shuffled list (checkpoint)
      for (int shuffle = 0; shuffle < TOTAL; shuffle++)
      {
         System.out.println(pool[shuffle]);
      }*/
      
      // Assign the first CHOOSE values to the imported array
      for (int n = 0; n < CHOOSE; n++)
      {
         q[n] = pool[n];
      }
      
      /*// Check the values of the q array (checkpoint)
      for (int sent = 0; sent < CHOOSE; sent++)
      {
         System.out.println(q[sent]);
      }*/
   }
   
   // A switch method bank that asks a question when its appropriate number
   // is called.
   public static int ask(int x, int qNum, int points, PrintWriter results)
   {
      Scanner keyboard = new Scanner(System.in);
   
   /* Be sure to gather all your questions here. Choose a few from each chapeter
   in the book, and make sure there are at least FORTY questions after you are
   finished. Seeded are forty placeholders. On each case, be sure to come back
   and complete the code with the question's statement and the correct answer.
   */
      // Finalize the qNum value.
      //final int QNUM = qNum;
      
      switch(qNum)
      {
         case 1:
            {
               System.out.println(x + ". Any programming language has words that have special meaning to the language. These are called: ");
               System.out.println("A: Punctuation");
               System.out.println("B: Programmer-defined names");
               System.out.println("C: Key words");
               System.out.println("D: Operators");
               System.out.print("Please answer A, B, C, or D: ");
            
               String ans = keyboard.nextLine();
               String cor = ("C");
               String chk = null;
            
               if(ans.equals(cor))
               {
                  System.out.println("That is correct.");
                  chk = "true";
                  points++;
               }
               else
               {
                  System.out.println("Incorrect.");
                  chk = "false";
               }
            
               results.println("     " + x + "      " + ans + "    " + chk);
            //return points;
               break;
            }
         case 2:
            {
               System.out.println(x + ". This is the name for the rules that must be followed when coding in a programming language.");
               System.out.println("A: Syntax");
               System.out.println("B: Punctuation");
               System.out.println("C: Key words");
               System.out.println("D: Operators");
               System.out.print("Please answer A, B, C, or D: ");
            
               String ans = keyboard.nextLine();
               String cor = ("A");
               String chk = null;
            
               if(ans.equals(cor))
               {
                  System.out.println("That is correct.");
                  chk = "true";
                  points++;
               }
               else
               {
                  System.out.println("Incorrect.");
                  chk = "false";
               }
            
               results.println("     " + x + "      " + ans + "    " + chk);
            //return points;
               break;
            }
         case 3:
            {
               System.out.println(x + ". The Java Compiler creates _____ from _____.");
               System.out.println("A: Machine code, byte code");
               System.out.println("B: Byte code, source code");
               System.out.println("C: Source code, byte code");
               System.out.println("D: HTML, machine code");
               System.out.print("Please answer A, B, C, or D: ");
            
               String ans = keyboard.nextLine();
               String cor = ("B");
               String chk = null;
            
               if(ans.equals(cor))
               {
                  System.out.println("That is correct.");
                  chk = "true";
                  points++;
               }
               else
               {
                  System.out.println("Incorrect.");
                  chk = "false";
               }
            
               results.println("     " + x + "      " + ans + "    " + chk);
            //return points;
               break;
            }
         case 4:
            {
               System.out.println(x + ". A group of statements, such as the contents of a class or method, are enclosed in: ");
               System.out.println("A: Braces {}");
               System.out.println("B: Parentheses ()");
               System.out.println("C: Brackets []");
               System.out.println("D: Any of these will do");
               System.out.print("Please answer A, B, C, or D: ");
            
               String ans = keyboard.nextLine();
               String cor = ("A");
               String chk = null;
            
               if(ans.equals(cor))
               {
                  System.out.println("That is correct.");
                  chk = "true";
                  points++;
               }
               else
               {
                  System.out.println("Incorrect.");
                  chk = "false";
               }
            
               results.println("     " + x + "      " + ans + "    " + chk);
            //return points;
               break;
            }
         case 5:
            {
               System.out.println(x + ". Which of the following is a valid assignment statement?");
               System.out.println("A: total == 9;");
               System.out.println("B: 72 = amount;");
               System.out.println("C: profit = 129");
               System.out.println("D: letter = 'W';");
               System.out.print("Please answer A, B, C, or D: ");
            
               String ans = keyboard.nextLine();
               String cor = ("D");
               String chk = null;
            
               if(ans.equals(cor))
               {
                  System.out.println("That is correct.");
                  chk = "true";
                  points++;
               }
               else
               {
                  System.out.println("Incorrect.");
                  chk = "false";
               }
            
               results.println("     " + x + "      " + ans + "    " + chk);
            //return points;
               break;
            }
         case 6:
            {
               System.out.println(x + ". Which of the following is a valid printline statement?");
               System.out.println("A: System.out.println + Hello World;");
               System.out.println("B: System.out.println(value);");
               System.out.println("C: out.System.println(value);");
               System.out.println("D: println.out(Programming is great fun);");
               System.out.print("Please answer A, B, C, or D: ");
            
               String ans = keyboard.nextLine();
               String cor = ("B");
               String chk = null;
            
               if(ans.equals(cor))
               {
                  System.out.println("That is correct.");
                  chk = "true";
                  points++;
               }
               else
               {
                  System.out.println("Incorrect.");
                  chk = "false";
               }
            
               results.println("     " + x + "      " + ans + "    " + chk);
            //return points;
               break;
            }
         case 7:
            {
               System.out.println(x + ". The negation operator is:");
               System.out.println("A: unary");
               System.out.println("B: binary");
               System.out.println("C: ternary");
               System.out.println("D: none of these");
               System.out.print("Please answer A, B, C, or D: ");
            
               String ans = keyboard.nextLine();
               String cor = ("A");
               String chk = null;
            
               if(ans.equals(cor))
               {
                  System.out.println("That is correct.");
                  chk = "true";
                  points++;
               }
               else
               {
                  System.out.println("Incorrect.");
                  chk = "false";
               }
            
               results.println("     " + x + "      " + ans + "    " + chk);
            //return points;
               break;
            }
         case 8:
            {
               System.out.println(x + ". These characters mark the beginning of a multi-line comment.");
               System.out.println("A: //");
               System.out.println("B: /*");
               System.out.println("C: */");
               System.out.println("D: /**");
               System.out.print("Please answer A, B, C, or D: ");
            
               String ans = keyboard.nextLine();
               String cor = ("B");
               String chk = null;
            
               if(ans.equals(cor))
               {
                  System.out.println("That is correct.");
                  chk = "true";
                  points++;
               }
               else
               {
                  System.out.println("Incorrect.");
                  chk = "false";
               }
            
               results.println("     " + x + "      " + ans + "    " + chk);
            //return points;
               break;
            }
         case 9:
            {
               System.out.println(x + ". These characters mark the beginning of a single-line comment.");
               System.out.println("A: //");
               System.out.println("B: /*");
               System.out.println("C: */");
               System.out.println("D: /**");
               System.out.print("Please answer A, B, C, or D: ");
            
               String ans = keyboard.nextLine();
               String cor = ("A");
               String chk = null;
            
               if(ans.equals(cor))
               {
                  System.out.println("That is correct.");
                  chk = "true";
                  points++;
               }
               else
               {
                  System.out.println("Incorrect.");
                  chk = "false";
               }
            
               results.println("     " + x + "      " + ans + "    " + chk);
            //return points;
               break;
            }
         case 10:
            {
               System.out.println(x + ". Which scanner class method would you use to read a String as input?");
               System.out.println("A: nextString");
               System.out.println("B: nextLine");
               System.out.println("C: readString");
               System.out.println("D: getLine");
               System.out.print("Please answer A, B, C, or D: ");
            
               String ans = keyboard.nextLine();
               String cor = ("B");
               String chk = null;
            
               if(ans.equals(cor))
               {
                  System.out.println("That is correct.");
                  chk = "true";
                  points++;
               }
               else
               {
                  System.out.println("Incorrect.");
                  chk = "false";
               }
            
               results.println("     " + x + "      " + ans + "    " + chk);
            //return points;
               break;
            }
         case 11:
            {
               System.out.println(x + ". Which scanner class method would you use to read a double as input?");
               System.out.println("A: getDouble");
               System.out.println("B: nextdouble");
               System.out.println("C: nextDouble");
               System.out.println("D: readDouble");
               System.out.print("Please answer A, B, C, or D: ");
            
               String ans = keyboard.nextLine();
               String cor = ("C");
               String chk = null;
            
               if(ans.equals(cor))
               {
                  System.out.println("That is correct.");
                  chk = "true";
                  points++;
               }
               else
               {
                  System.out.println("Incorrect.");
                  chk = "false";
               }
            
               results.println("     " + x + "      " + ans + "    " + chk);
            //return points;
               break;
            }
         case 12:
            {
               System.out.println(x + ". This type of operator lets you manually convert a value, even if that means that a narrowing conversion will take place.");
               System.out.println("A: cast");
               System.out.println("B: binary");
               System.out.println("C: uploading");
               System.out.println("D: dot");
               System.out.print("Please answer A, B, C, or D: ");
            
               String ans = keyboard.nextLine();
               String cor = ("A");
               String chk = null;
            
               if(ans.equals(cor))
               {
                  System.out.println("That is correct.");
                  chk = "true";
                  points++;
               }
               else
               {
                  System.out.println("Incorrect.");
                  chk = "false";
               }
            
               results.println("     " + x + "      " + ans + "    " + chk);
            //return points;
               break;
            }
         case 13:
            {
               System.out.println(x + ". final int VALUE = 10. Which of the following lines of code will change value to 9?");
               System.out.println("A: VALUE--;");
               System.out.println("B: VALUE = 9;");
               System.out.println("C: VALUE = (int)9;");
               System.out.println("D: None of these, you can't change a final value after it's been declared.");
               System.out.print("Please answer A, B, C, or D: ");
            
               String ans = keyboard.nextLine();
               String cor = ("D");
               String chk = null;
            
               if(ans.equals(cor))
               {
                  System.out.println("That is correct.");
                  chk = "true";
                  points++;
               }
               else
               {
                  System.out.println("Incorrect.");
                  chk = "false";
               }
            
               results.println("     " + x + "      " + ans + "    " + chk);
            //return points;
               break;
            }
         case 14:
            {
               System.out.println(x + ". if, while, and for are examples of:");
               System.out.println("A: sequence structures");
               System.out.println("B: decision structures");
               System.out.println("C: pathway structures");
               System.out.println("D: class structures");
               System.out.print("Please answer A, B, C, or D: ");
            
               String ans = keyboard.nextLine();
               String cor = ("B");
               String chk = null;
            
               if(ans.equals(cor))
               {
                  System.out.println("That is correct.");
                  chk = "true";
                  points++;
               }
               else
               {
                  System.out.println("Incorrect.");
                  chk = "false";
               }
            
               results.println("     " + x + "      " + ans + "    " + chk);
            //return points;
               break;
            }
         case 15:
            {
               System.out.println(x + ". >, <, and == are:");
               System.out.println("A: relational operators");
               System.out.println("B: logical operators");
               System.out.println("C: conditional operators");
               System.out.println("D: ternary operators");
               System.out.print("Please answer A, B, C, or D: ");
            
               String ans = keyboard.nextLine();
               String cor = ("A");
               String chk = null;
            
               if(ans.equals(cor))
               {
                  System.out.println("That is correct.");
                  chk = "true";
                  points++;
               }
               else
               {
                  System.out.println("Incorrect.");
                  chk = "false";
               }
            
               results.println("     " + x + "      " + ans + "    " + chk);
            //return points;
               break;
            }
         case 16:
            {
               System.out.println(x + ". &&, ||, and ! are:");
               System.out.println("A: relational operators");
               System.out.println("B: logical operators");
               System.out.println("C: conditional operators");
               System.out.println("D: ternary operators");
               System.out.print("Please answer A, B, C, or D: ");
            
               String ans = keyboard.nextLine();
               String cor = ("B");
               String chk = null;
            
               if(ans.equals(cor))
               {
                  System.out.println("That is correct.");
                  chk = "true";
                  points++;
               }
               else
               {
                  System.out.println("Incorrect.");
                  chk = "false";
               }
            
               results.println("     " + x + "      " + ans + "    " + chk);
            //return points;
               break;
            }
         case 17:
            {
               System.out.println(x + ". How does the char 'A' compare to the char 'B'");
               System.out.println("A: 'A' > 'B'");
               System.out.println("B: 'A' < 'B'");
               System.out.println("C: 'A' == 'B'");
               System.out.println("D: You cannot compare chars");
               System.out.print("Please answer A, B, C, or D: ");
            
               String ans = keyboard.nextLine();
               String cor = ("B");
               String chk = null;
            
               if(ans.equals(cor))
               {
                  System.out.println("That is correct.");
                  chk = "true";
                  points++;
               }
               else
               {
                  System.out.println("Incorrect.");
                  chk = "false";
               }
            
               results.println("     " + x + "      " + ans + "    " + chk);
            //return points;
               break;
            }
         case 18:
            {
               System.out.println(x + ". An else clause always goes with:");
               System.out.println("A: the closest if clause that doesn't already have an else");
               System.out.println("B: the closest if clause");
               System.out.println("C: the if clause that is randomly selected by the compiler");
               System.out.println("D: none of these");
               System.out.print("Please answer A, B, C, or D: ");
            
               String ans = keyboard.nextLine();
               String cor = ("A");
               String chk = null;
            
               if(ans.equals(cor))
               {
                  System.out.println("That is correct.");
                  chk = "true";
                  points++;
               }
               else
               {
                  System.out.println("Incorrect.");
                  chk = "false";
               }
            
               results.println("     " + x + "      " + ans + "    " + chk);
            //return points;
               break;
            }
         case 19:
            {
               System.out.println(x + ". The conditional operator takes this many operands.");
               System.out.println("A: one");
               System.out.println("B: two");
               System.out.println("C: three");
               System.out.println("D: four");
               System.out.print("Please answer A, B, C, or D: ");
            
               String ans = keyboard.nextLine();
               String cor = ("C");
               String chk = null;
            
               if(ans.equals(cor))
               {
                  System.out.println("That is correct.");
                  chk = "true";
                  points++;
               }
               else
               {
                  System.out.println("Incorrect.");
                  chk = "false";
               }
            
               results.println("     " + x + "      " + ans + "    " + chk);
            //return points;
               break;
            }
         case 20:
            {
               System.out.println(x + ". In the expression number++, the ++ is in what mode?");
               System.out.println("A: prefix");
               System.out.println("B: pretest");
               System.out.println("C: postfix");
               System.out.println("D: posttest");
               System.out.print("Please answer A, B, C, or D: ");
            
               String ans = keyboard.nextLine();
               String cor = ("C");
               String chk = null;
            
               if(ans.equals(cor))
               {
                  System.out.println("That is correct.");
                  chk = "true";
                  points++;
               }
               else
               {
                  System.out.println("Incorrect.");
                  chk = "false";
               }
            
               results.println("     " + x + "      " + ans + "    " + chk);
            //return points;
               break;
            }
         case 21:
            {
               System.out.println(x + ". This type of loop always executes at least once.");
               System.out.println("A: while");
               System.out.println("B: do-while");
               System.out.println("C: for");
               System.out.println("D: any of these");
               System.out.print("Please answer A, B, C, or D: ");
            
               String ans = keyboard.nextLine();
               String cor = ("B");
               String chk = null;
            
               if(ans.equals(cor))
               {
                  System.out.println("That is correct.");
                  chk = "true";
                  points++;
               }
               else
               {
                  System.out.println("Incorrect.");
                  chk = "false";
               }
            
               results.println("     " + x + "      " + ans + "    " + chk);
            //return points;
               break;
            }
         case 22:
            {
               System.out.println(x + ". This expression is executed by the for loop only once, regardless of the number of iterations.");
               System.out.println("A: initialization expression");
               System.out.println("B: test expression");
               System.out.println("C: update expression");
               System.out.println("D: pre-increment expression");
               System.out.print("Please answer A, B, C, or D: ");
            
               String ans = keyboard.nextLine();
               String cor = ("A");
               String chk = null;
            
               if(ans.equals(cor))
               {
                  System.out.println("That is correct.");
                  chk = "true";
                  points++;
               }
               else
               {
                  System.out.println("Incorrect.");
                  chk = "false";
               }
            
               results.println("     " + x + "      " + ans + "    " + chk);
            //return points;
               break;
            }
         case 23:
            {
               System.out.println(x + ". This is a variable that keeps a running total.");
               System.out.println("A: sentinel");
               System.out.println("B: sum");
               System.out.println("C: total");
               System.out.println("D: accumulator");
               System.out.print("Please answer A, B, C, or D: ");
            
               String ans = keyboard.nextLine();
               String cor = ("D");
               String chk = null;
            
               if(ans.equals(cor))
               {
                  System.out.println("That is correct.");
                  chk = "true";
                  points++;
               }
               else
               {
                  System.out.println("Incorrect.");
                  chk = "false";
               }
            
               results.println("     " + x + "      " + ans + "    " + chk);
            //return points;
               break;
            }
         case 24:
            {
               System.out.println(x + ". To open a file for writing, you use the following class.");
               System.out.println("A: PrintWriter");
               System.out.println("B: FileOpen");
               System.out.println("C: OutputFile");
               System.out.println("D: FileReader");
               System.out.print("Please answer A, B, C, or D: ");
            
               String ans = keyboard.nextLine();
               String cor = ("A");
               String chk = null;
            
               if(ans.equals(cor))
               {
                  System.out.println("That is correct.");
                  chk = "true";
                  points++;
               }
               else
               {
                  System.out.println("Incorrect.");
                  chk = "false";
               }
            
               results.println("     " + x + "      " + ans + "    " + chk);
            //return points;
               break;
            }
         case 25:
            {
               System.out.println(x + ". When a program is done using a file, it should do this.");
               System.out.println("A: erase the file");
               System.out.println("B: close the file");
               System.out.println("C: throw an exception");
               System.out.println("D: reset the read position");
               System.out.print("Please answer A, B, C, or D: ");
            
               String ans = keyboard.nextLine();
               String cor = ("B");
               String chk = null;
            
               if(ans.equals(cor))
               {
                  System.out.println("That is correct.");
                  chk = "true";
                  points++;
               }
               else
               {
                  System.out.println("Incorrect.");
                  chk = "false";
               }
            
               results.println("     " + x + "      " + ans + "    " + chk);
            //return points;
               break;
            }
         case 26:
            {
               System.out.println(x + ". This class allows you to use the print and println methods to write data to a file.");
               System.out.println("A: File");
               System.out.println("B: FileReader");
               System.out.println("C: OutputFile");
               System.out.println("D: PrintWriter");
               System.out.print("Please answer A, B, C, or D: ");
            
               String ans = keyboard.nextLine();
               String cor = ("C");
               String chk = null;
            
               if(ans.equals(cor))
               {
                  System.out.println("That is correct.");
                  chk = "true";
                  points++;
               }
               else
               {
                  System.out.println("Incorrect.");
                  chk = "false";
               }
            
               results.println("     " + x + "      " + ans + "    " + chk);
            //return points;
               break;
            }
         case 27:
            {
               System.out.println(x + ". Which line is a syntactially correct usage of the random class?");
               System.out.println("A: int number = randomNumbers,nextInt(-20);");
               System.out.println("B: int number = randomNumbers.nextDouble();");
               System.out.println("C: int number = randomNumbers.nextInt(100)");
               System.out.println("D: int number = randomNumbers.nextInt(300) - 150;");
               System.out.print("Please answer A, B, C, or D: ");
            
               String ans = keyboard.nextLine();
               String cor = ("D");
               String chk = null;
            
               if(ans.equals(cor))
               {
                  System.out.println("That is correct.");
                  chk = "true";
                  points++;
               }
               else
               {
                  System.out.println("Incorrect.");
                  chk = "false";
               }
            
               results.println("     " + x + "      " + ans + "    " + chk);
            //return points;
               break;
            }
         case 28:
            {
               System.out.println(x + ". This type of method does not return a value.");
               System.out.println("A: null");
               System.out.println("B: void");
               System.out.println("C: empty");
               System.out.println("D: anonymous");
               System.out.print("Please answer A, B, C, or D: ");
            
               String ans = keyboard.nextLine();
               String cor = ("B");
               String chk = null;
            
               if(ans.equals(cor))
               {
                  System.out.println("That is correct.");
                  chk = "true";
                  points++;
               }
               else
               {
                  System.out.println("Incorrect.");
                  chk = "false";
               }
            
               results.println("     " + x + "      " + ans + "    " + chk);
            //return points;
               break;
            }
         case 29:
            {
               System.out.println(x + ". The body of a method is enclosed in:");
               System.out.println("A: Parentheses ()");
               System.out.println("B: Square brackets []");
               System.out.println("C: Curly braces {}");
               System.out.println("D: None of these");
               System.out.print("Please answer A, B, C, or D: ");
            
               String ans = keyboard.nextLine();
               String cor = ("C");
               String chk = null;
            
               if(ans.equals(cor))
               {
                  System.out.println("That is correct.");
                  chk = "true";
                  points++;
               }
               else
               {
                  System.out.println("Incorrect.");
                  chk = "false";
               }
            
               results.println("     " + x + "      " + ans + "    " + chk);
            //return points;
               break;
            }
         case 30:
            {
               System.out.println(x + ". A method header can contain:");
               System.out.println("A: the method return type");
               System.out.println("B: the method name");
               System.out.println("C: a list of parameter declarations");
               System.out.println("D: all of these");
               System.out.print("Please answer A, B, C, or D: ");
            
               String ans = keyboard.nextLine();
               String cor = ("D");
               String chk = null;
            
               if(ans.equals(cor))
               {
                  System.out.println("That is correct.");
                  chk = "true";
                  points++;
               }
               else
               {
                  System.out.println("Incorrect.");
                  chk = "false";
               }
            
               results.println("     " + x + "      " + ans + "    " + chk);
            //return points;
               break;
            }
         case 31:
            {
               System.out.println(x + ". A variable that receives a value that is passed into a method is known as a(n)");
               System.out.println("A: parameter");
               System.out.println("B: argument");
               System.out.println("C: signal");
               System.out.println("D: return value");
               System.out.print("Please answer A, B, C, or D: ");
            
               String ans = keyboard.nextLine();
               String cor = ("A");
               String chk = null;
            
               if(ans.equals(cor))
               {
                  System.out.println("That is correct.");
                  chk = "true";
                  points++;
               }
               else
               {
                  System.out.println("Incorrect.");
                  chk = "false";
               }
            
               results.println("     " + x + "      " + ans + "    " + chk);
            //return points;
               break;
            }
         case 32:
            {
               System.out.println(x + ". This statement causes a method to end and sends a value back to the statement that called the method.");
               System.out.println("A: end");
               System.out.println("B: send");
               System.out.println("C: exit");
               System.out.println("D: return");
               System.out.print("Please answer A, B, C, or D: ");
            
               String ans = keyboard.nextLine();
               String cor = ("D");
               String chk = null;
            
               if(ans.equals(cor))
               {
                  System.out.println("That is correct.");
                  chk = "true";
                  points++;
               }
               else
               {
                  System.out.println("Incorrect.");
                  chk = "false";
               }
            
               results.println("     " + x + "      " + ans + "    " + chk);
            //return points;
               break;
            }
         case 33:
            {
               System.out.println(x + ". This key word causes an object to be created in memory.");
               System.out.println("A: create");
               System.out.println("B: new");
               System.out.println("C: object");
               System.out.println("D: construct");
               System.out.print("Please answer A, B, C, or D: ");
            
               String ans = keyboard.nextLine();
               String cor = ("B");
               String chk = null;
            
               if(ans.equals(cor))
               {
                  System.out.println("That is correct.");
                  chk = "true";
                  points++;
               }
               else
               {
                  System.out.println("Incorrect.");
                  chk = "false";
               }
            
               results.println("     " + x + "      " + ans + "    " + chk);
            //return points;
               break;
            }
         case 34:
            {
               System.out.println(x + ". This is a method that gets a value from a class's field, but doesn't change it.");
               System.out.println("A: Accessor");
               System.out.println("B: Constructor");
               System.out.println("C: Void");
               System.out.println("D: Mutator");
               System.out.print("Please answer A, B, C, or D: ");
            
               String ans = keyboard.nextLine();
               String cor = ("A");
               String chk = null;
            
               if(ans.equals(cor))
               {
                  System.out.println("That is correct.");
                  chk = "true";
                  points++;
               }
               else
               {
                  System.out.println("Incorrect.");
                  chk = "false";
               }
            
               results.println("     " + x + "      " + ans + "    " + chk);
            //return points;
               break;
            }
         case 35:
            {
               System.out.println(x + ". Two or more methods in a class may have the same name, as long as this is different.");
               System.out.println("A: their return values");
               System.out.println("B: their access specifier");
               System.out.println("C: their parameter lists");
               System.out.println("D: their memory address");
               System.out.print("Please answer A, B, C, or D: ");
            
               String ans = keyboard.nextLine();
               String cor = ("C");
               String chk = null;
            
               if(ans.equals(cor))
               {
                  System.out.println("That is correct.");
                  chk = "true";
                  points++;
               }
               else
               {
                  System.out.println("Incorrect.");
                  chk = "false";
               }
            
               results.println("     " + x + "      " + ans + "    " + chk);
            //return points;
               break;
            }
         case 36:
            {
               System.out.println(x + ". This is automatically called when an instance of a class is created.");
               System.out.println("A: accessor");
               System.out.println("B: constructor");
               System.out.println("C: void");
               System.out.println("D: mutator");
               System.out.print("Please answer A, B, C, or D: ");
            
               String ans = keyboard.nextLine();
               String cor = ("B");
               String chk = null;
            
               if(ans.equals(cor))
               {
                  System.out.println("That is correct.");
                  chk = "true";
                  points++;
               }
               else
               {
                  System.out.println("Incorrect.");
                  chk = "false";
               }
            
               results.println("     " + x + "      " + ans + "    " + chk);
            //return points;
               break;
            }
         case 37:
            {
               System.out.println(x + ". In an array declaration, this indicates the number of elements that the array will have.");
               System.out.println("A: subscript");
               System.out.println("B: size declarator");
               System.out.println("C: element sum");
               System.out.println("D: reference variable");
               System.out.print("Please answer A, B, C, or D: ");
            
               String ans = keyboard.nextLine();
               String cor = ("B");
               String chk = null;
            
               if(ans.equals(cor))
               {
                  System.out.println("That is correct.");
                  chk = "true";
                  points++;
               }
               else
               {
                  System.out.println("Incorrect.");
                  chk = "false";
               }
            
               results.println("     " + x + "      " + ans + "    " + chk);
            //return points;
               break;
            }
         case 38:
            {
               System.out.println(x + ". The first _____ in an array is always _____.");
               System.out.println("A: subscript, 1");
               System.out.println("B: size declarator, -1");
               System.out.println("C: subscript, 0");
               System.out.println("D: address, 1 less than the number of elements");
               System.out.print("Please answer A, B, C, or D: ");
            
               String ans = keyboard.nextLine();
               String cor = ("C");
               String chk = null;
            
               if(ans.equals(cor))
               {
                  System.out.println("That is correct.");
                  chk = "true";
                  points++;
               }
               else
               {
                  System.out.println("Incorrect.");
                  chk = "false";
               }
            
               results.println("     " + x + "      " + ans + "    " + chk);
            //return points;
               break;
            }
         case 39:
            {
               System.out.println(x + ". Array bounds checking happens:");
               System.out.println("A: when the program is compiled");
               System.out.println("B: when the program is run");
               System.out.println("C: when the program is saved");
               System.out.println("D: when the program is loaded into memory");
               System.out.print("Please answer A, B, C, or D: ");
            
               String ans = keyboard.nextLine();
               String cor = ("B");
               String chk = null;
            
               if(ans.equals(cor))
               {
                  System.out.println("That is correct.");
                  chk = "true";
                  points++;
               }
               else
               {
                  System.out.println("Incorrect.");
                  chk = "false";
               }
            
               results.println("     " + x + "      " + ans + "    " + chk);
            //return points;
               break;
            }
         case 40:
            {
               System.out.println(x + ". When initializing a two-dimensional array, you enclose each row's initialization list in:");
               System.out.println("A: braces");
               System.out.println("B: parentheses");
               System.out.println("C: brackets");
               System.out.println("D: quotation marks");
               System.out.print("Please answer A, B, C, or D: ");
            
               String ans = keyboard.nextLine();
               String cor = ("A");
               String chk = null;
            
               if(ans.equals(cor))
               {
                  System.out.println("That is correct.");
                  chk = "true";
                  points++;
               }
               else
               {
                  System.out.println("Incorrect.");
                  chk = "false";
               }
            
               results.println("     " + x + "      " + ans + "    " + chk);
            //return points;
               break;
            }
         
         default:
            {
               System.out.println("Error! Check the code and try again.");
               results.close();
               System.exit(0);
            }
      }
      return points;
   }
   
   // A method that displays the results.
   public static void displayResults(int points)
   {
      System.out.println("   The quiz is complete. Your score was " + points + " points.");
      
      if(points == 6)
      {
         System.out.println("Your grade was a D.");
      }
      else if(points == 7)
      {
         System.out.println("Your grade was a C.");
      }
      else if(points == 8)
      {
         System.out.println("Your grade was a B.");
      }
      else if(points > 8)
      {
         System.out.println("Your grade was an A.");
         if(points == 10)
         {
            System.out.println("Perfect score!");
         }
      }
      else
      {
         System.out.println("Your grade was an F.");
      }
      System.out.println("   Your score has been recorded. Thank you for   ");
      System.out.println("taking this quiz. See you next time...           ");
   }
}