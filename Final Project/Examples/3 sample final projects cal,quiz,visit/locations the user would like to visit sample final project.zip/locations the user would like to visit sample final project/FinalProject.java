// name
// date
// Final Project

// import java scanner
import java.util.Scanner;

//import random number generator
import java.util.Random;

//import I/O
import java.io.*;

public class FinalProject {
   // method that saves to a txt file the locations they want to visit
   public static void run() throws IOException 
   {
      // Variables to write to file
      String fileName;
      String destinations;
      int numLocations;
      Scanner scanner = new Scanner(System.in);
      
      // Creating Scanner instructions 
      System.out.println("Welcome to Vacation Weather!!! Please enter in the following information " );
      
      // printing to another file
      System.out.println("How many locations would you like to visit?");
      numLocations = scanner.nextInt();
      scanner.nextLine();
      System.out.println("Enter the name of the file you wish to save these locations");
      fileName = scanner.nextLine();
     
     // opening file
      try
      {
         PrintWriter outputFile = new PrintWriter(fileName);
      
         for (int i = 1; i <= numLocations; i++)
         {
            System.out.print("Enter the a destination starting with the most desired, Hawaii, Seattle, Ellensburg, Los Angeles, New York, Miami, Chicago, Tempe " + i + ": ");
            destinations = scanner.nextLine();
         
            outputFile.println(destinations);
         }
         outputFile.close();
      }
      catch (FileNotFoundException e)
      {
      }
     
      System.out.println("Your destination list has been saved. You may go open the file you saved. ");
   } 

      
    // Main routine
   public static void main(String [] args)
   
   {
      // Variable decleration
      Scanner scanner = new Scanner(System.in);
      Random number = new Random();
      String city;
      int weather;
      String degrees = "\u00b0";
      
      // running my run method which writes to a file and catch's error. 
      try
      {
         run();
      }
      catch (IOException e)
      {
      }
   
      // array decleration
      String[] outside = new String[5];
   
      outside[0] = "sunny";
      outside[1] = "cloudy";
      outside[2] = "raining";
      outside[3] = "snowing";
      outside[4] = "partly cloudy";
   
      // simulation the weather of selected cities.
      System.out.println("");
      System.out.println("This simulation will inform you of the temperature of your choosen destination. ");
      System.out.println("Pleae enter one of these cities you would like to visit. ");
      System.out.println("Hawaii, Seattle, Ellensburg, Los Angeles, New York, Miami, Chicago, Tempe ");
      System.out.println("To terminate the program type quit");
      
      // loops all the following till user types quit.
      while (true)
      {
      
         city = scanner.nextLine();
      
      // Converting text to lowercase
      // Incase the user capitalizes any letters it will still understand it
      
         city = city.toLowerCase();
      
      
      // indicates the weather of the city they selected using if else if and RNG
         switch(city)
         {
            case "hawaii": 
               weather = number.nextInt(110-72) + 72;
               if (weather >= 100)
               {
                  System.out.println("You might want to consider a new location based on the a balmy " + weather + degrees + " and " + outside[0]);
               }
               else if (weather >= 85 && weather <= 99)
               {
                  System.out.println("This is an ideal time to visit Hawaii based on the lovely temperature of " + weather + degrees + " and it's " +outside[0]);
               }
               else
               {
                  System.out.println("It's a chilly " + weather + degrees + " and " + outside[2] + ", I recommended finding a different location.");
               }   
               break;
            
            case "seattle": 
               weather = number.nextInt(84-31) + 31;
               if (weather >= 68)
               {
                  System.out.println("A nice " + outside[0] + " day with a temperature of " + weather + degrees + ", this is a perfect time to visit Seattle!");
               }
               else if (weather >=50 && weather <= 67)
               {
                  System.out.println(weather + degrees + " and " + outside[1] + " is not an ideal time to be visiting Seattle, but it could be worse.");
               }
               else
               {
                  System.out.println("Unless you like the cold and wet, " + weather + degrees + " and " + outside[2] + " out means you shouldn't be visiting Seattle.");
               } 
               break;
            
            case "ellensburg":
               weather = number.nextInt(87-8) + 8;
               if (weather >= 70)
               {
                  System.out.println("A nice calm breeze and a temperature of " + weather + degrees + " and " + outside[0] + " out makes Ellensburg a good destination to visit.");
               }
               else if (weather >=36 && weather <= 67)
               {
                  System.out.println("With a current temperature of " + weather + degrees + " and " + outside[1] + ", I would expect heavy winds and unfavorable rain.");
               }
               else
               {
                  System.out.println("If you are a fan of cold weather, Ellensburg can provide you with a much needed chilly vacation with a temperature of " + weather + degrees + " and " + outside[3]);
               }
               break;
            
            case "la":
            case "los angeles":
               weather = number.nextInt(94-45) + 45;  
               if (weather >= 73)
               {
                  System.out.println("This is a perfect time to go celebrity watching in LA as the temperature is a warm " + outside[0] + " " + weather + degrees + " out.");
               }
               else if (weather >=60 && weather <= 72)
               {
                  System.out.println("A relaxing " + weather + degrees + " and " + outside[1] + " outside, makes LA a hotspot for long walks on the beach.");
               }
               else
               {
                  System.out.println("A brisk " + outside[4] + " " + weather + degrees + " out means finding another location might be your best option.");
               }
               break;
            
            case "ny":  
            case "new york":
               weather = number.nextInt(98-19) + 19;
               if (weather >= 85)
               {
                  System.out.println("If you enjoy a humid " + outside[0] + " and hot vacation destination, New York is the spot to be with a current temperature of " + weather + degrees);
               }
               else if (weather >=45 && weather <= 73)
               {
                  System.out.println(+ weather + degrees + " out and " + outside[4] + " makes a stroll through central park a grand idea well also providing the option of venturing over to Time Square.");
               }
               else
               {
                  System.out.println("If you want to freeze to death in the " + outside[3] + " conditions of NY, enjoy the arctic " + weather + degrees);
               }           
               break;
            
            case "miami":
               weather = number.nextInt(103-50) + 50;
               if (weather >= 85)
               {
                  System.out.println("With the temperature outside being a hot and " + outside[0] + " " + weather + degrees + ", it's the perfect time to hit the beach.");
               }
               else if (weather >=71 && weather <= 84)
               {
                  System.out.println("It isn't the best time to go to Miami but it could be worse then " + weather + degrees + " and " + outside[4]);
               }
               else
               {
                  System.out.println("Another vacation destination might suit you better as it is " + outside[1] + " with a temperature of " + weather + degrees);
               }             
               break;
            
            case "chicago":
               weather = number.nextInt(83-17) +17;
               if (weather >= 65)
               {
                  System.out.println("Want to go see the bean? " + weather + degrees + " and " + outside[0] + " is a wonderful temperature to do just that");
               }
               else if (weather >=33 && weather <= 64)
               {
                  System.out.println("There are better times to visit Chicago, but again, it could be worse then a " + outside[1] + " " + weather + degrees);
               }
               else
               {
                  System.out.println("Unless you want to hang out inside all day due to the the below freezing temperature of " + weather + degrees + " and " + outside[3] + ", find another vacation destination");
               }             
               break;
         
            case "tempe":
               weather = number.nextInt(115-62) +62;
               if (weather >= 100)
               {
                  System.out.println(weather + degrees + " outside and " + outside[0] + " is to hot and should be avoided at all cost!");
               }
               else if (weather >=80 && weather <= 99)
               {
                  System.out.println("Still a toasty " + weather + degrees + " but it is manageable with the " + outside[1] + " weather.");
               }
               else
               {
                  System.out.println(weather + degrees + " and " + outside[4] + " is still comfortable for vacation.");
               }            
               break;
         
            case "quit":
               {
                  System.out.println("Thank you for using Vacation Weather, we hope you found an ideal vacation destination!");
                  System.exit(0);
               }
               break;
         
            default:
               {
                  System.out.println("The city you entered is not recognized, please enter another destiation.");
               }
               break;
            
               
         
         }
       
      
      }  
         
      
   }
}
