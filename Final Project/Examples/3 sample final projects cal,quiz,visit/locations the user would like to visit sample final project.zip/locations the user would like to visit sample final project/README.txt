File	: README.txt
Author  : name
Project : CS110 Final Project
Date	: date
=============================

Explanation: This program helps you decide where you would like to vacation. It asks a list of ideal
	     locations that might be of interest then informs you of the temperature, weather, and
	     if it is a good time of year to visit. This also saves the locations in a txt file.

How to use:  This program is simple to use. It requires a user input which is straight forward in
	     the instructions that are printed to the screen. This will continue to loop the
	     program till the user types "quit" which is also listed in the instructions.

Known bugs:  None

Contact:     Private

