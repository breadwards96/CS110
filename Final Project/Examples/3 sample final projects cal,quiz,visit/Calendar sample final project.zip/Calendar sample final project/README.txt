This is a calendar program I wrote.

The program will prompt you to write tasks for each day of the week and then will print the tasks to a file of which name you 
specify that will apear where ever you have the classes saved on the computer.

You can add up to the value the public static final int NUMTASKS has, trying to add more will crash the program.

If you select a day to write tasks for, selecting it again after exiting to the day selection step will corrupt the data 
you have written for that day previously.

