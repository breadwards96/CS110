// GIVEN FOR HW5 Use this file and delete this line************************
// name
// date
// honor code
// description
// pseudocode
import java.util.Scanner;

// A "casino" class
public class Casino {

    public static void main(String Args[]) {

        // four reference variables, gambler1, gambler2, gambler3, gambler4, 
        // each of which references a new instance of an object of type Gambler,
        // created using the non-standard constructor



        // set winning percentage for each player (sample percentages)
        // gambler1 has winning percentage of 0.34
        // gambler2 has winning percentage of 0.21
        // gambler3 has winning percentage of 0.59
        // gambler4 has winning percentage of 0.51


        // invoke the getGamblerName and getWinningPercentage methods
        // for each Gambler object, to retrieve that information, and print
        // it to the screen


        // create a variable, keyboard, of type Scanner, and set it
        // equal to a new object of type Scanner, that "listens" to
        // System.in	





        // a while loop, with a "true" conditional
        while (true) {
            // For each of the four gamblers, retrieve the gambler's name, how much money hey/she spent,
            // how much money he/she currently has, and the gambler's net profit. Print that information
            // to the screen. Look at the homework handout for sample output					
            // use a System.out.print statement to ask how much money each gambler should bet. 
            // Then declare a variable dollarsBet of type double, and set its value to the keyboard's
            // keystroke (be sure to use keyboard.nextDouble()).
            // If the user enters 0, then issue a break statement, so that the while loop terminates
            // Else, invoke the gambleAnotherRound method of each Gambler, and pass it the variable dollarsBet		
        }

    }
}
