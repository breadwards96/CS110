// Author: Brandon Edwards
// Date: 10/3/17
// Honor Code: I pledge that this submission is solely my work,
//and that I have neither given to nor received help from anyone
//other than the instructor or TAs.
// File: FindingSyntaxErrors.java 

/* A simple class that contains syntax errors */
public class FindingSyntaxErrors { 
 
   // The main method 
   public static void main(String[] args) { 
 
      // Declare a variable of type integer
      int zipCode = 98926; 

      // Invoke the print and println methods from System.out 
      System.out.print("Wellington P. Wildcat "); 
      System.out.println(" is the official mascot of CWU.");
      System.out.println("He lives at zip code " + zipCode);
   } 
}

